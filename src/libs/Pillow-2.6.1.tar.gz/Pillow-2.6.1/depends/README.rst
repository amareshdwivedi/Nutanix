Depends
=======

Scripts in this directory can be used to download, build & install non-packaged dependencies; useful for testing with Travis CI.
